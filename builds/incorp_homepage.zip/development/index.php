<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <link rel="stylesheet" href="css/main.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <header id="masthead">
      <div class="topbar">
        <div class="container">
          <div class="topbar-cart"><a href="#">Shopping Cart ($0)</a></div>
          <div class="topbar-login"><a href="#">Login</a></div>
        </div><!-- .container -->
      </div><!-- .topbar -->

      <div class="header">
        <div class="container">
          <a class="navbar-brand" href="/"><h1 class="sr-only">Incorp</h1></a>
          <a class="sr-only sr-only-focusable" href="#content">Skip to main content</a>
          <div class="header-phone"><a href="#">1.800.246.2677</a></div>
          <div class="header-chat"><a href="#">Live Chat</a></div>
        </div><!-- .container -->
      </div><!-- .header -->

      <nav class="navbar navbar-default">
        <div class="container">
          <div class="navbar-toggle-container">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div id="menu" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li class="dropdown dropdown-large">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Services</a>
              <ul class="dropdown-menu dropdown-menu-large row">
                <li class="col-sm-3">
      						<ul>
      							<li class="dropdown-header">Main Services</li>
      							<li><a href="#">Registered Agent Services</a></li>
      							<li><a href="#">Incorporation / Formation Services</a></li>
      							<li><a href="#">Certificate of Good Standing</a></li>
      							<li><a href="#">Foreign Qualifications</a></li>
      							<li><a href="#">Dissolution/Withdrawal/Cancellation</a></li>
      						</ul>
      					</li>
      					<li class="col-sm-3">
      						<ul>
      							<li class="dropdown-header">Business Services</li>
      							<li><a href="#">Business Licenses</a></li>
      							<li><a href="#">Corporate Record Kits &amp; Seals</a></li>
      							<li><a href="#">DBA (Doing Business As)</a></li>
      							<li><a href="#">EIN ( Federal Tax ID Number)</a></li>
      							<li><a href="#">Managed Report Services</a></li>
      							<li><a href="#">Books &amp; Publications</a></li>
      						</ul>
      					</li>
      					<li class="col-sm-3">
      						<ul>
      							<li class="dropdown-header">Protecting Your Business</li>
      							<li><a href="#">Entitywatch</a></li>
      							<li><a href="#">Business Identity Theft Protection</a></li>
      							<li><a href="#">Trademarks</a></li>
      							<li><a href="#">Copyrights</a></li>
      						</ul>
      					</li>
      					<li class="col-sm-3">
      						<ul>
      							<li class="dropdown-header">Amendments</li>
      							<li><a href="#">Name Amendment Filing Services</a></li>
      							<li><a href="#">Article Amendment Filing Services</a></li>
      							<li><a href="#">Share Amendment Filing Services</a></li>
                    <li class="divider"></li>
                    <li class="dropdown-header">Document Certify &amp; Copies</li>
                    <li><a href="#">Apostille Service (Non US)</a></li>
                    <li><a href="#">Certified Copies (US)</a></li>
      						</ul>
      					</li>
              </ul><!-- .dropdown-menu -->
            </li>
            <li><a href="#about">Information</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#about">Help Center</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div><!-- #menu -->
        </div><!-- .container -->
      </nav>

    </header><!-- #masthead -->

    <div id="intro">
      <div class="container">
        <h2>Registered agent service, entity formations, and corporate compliance.</h2>
        <button type="button" class="btn btn-lg btn-info">Talk to an Expert</button>
      </div><!-- .container -->
      <div class="gradient"></div>
    </div><!-- .jumbotron -->

    <div id="options">
      <div class="container">
          <div class="option1">
            <h2>Order Registered Agent Services</h2>
            <div class="desc">Registered Agent service for a new or existing entity!</div>
            <button type="button" class="btn btn-lg btn-success">Get Started</button>
          </div>
          <div class="option2">
            <h2>Form an LLC or Corporation</h2>
            <div class="desc">Order a New Corporation, Limited-Liability Company (LLC) or other type of entity!</div>
            <button type="button" class="btn btn-lg btn-success">Get Started</button>
          </div>
      </div><!-- .container -->
    </div><!-- .options -->

    <div id="quotes">
      <div class="container">
          <h2>Price Quote</h2>
          <p class="lead">INCORP will beat any competitor’s price on on any product or service guaranteed!</p>
          <button class="btn btn-lg btn-primary">Get Price Quote</button>
      </div><!-- .container -->
    </div><!-- .quotes -->

    <div id="services">
      <div class="container">
        <h2>We offer great services for our customers. Select which service best fits your needs!</h2>
        <div class="services-list">
          <div class="service"><a href="#">Form LLC or Corporation</a></div>
          <div class="service"><a href="#">Registered Agent Services</a></div>
          <div class="service"><a href="#">Order Foreign Qualification Service</a></div>
          <div class="service"><a href="#">Order DBA (Doing Business As) </a></div>
          <div class="service"><a href="#">Certificate of Good Standing</a></div>
          <div class="service"><a href="#">Order Corporate Kit or Seal</a></div>
          <div class="service"><a href="#">Order Dissolution Service</a></div>
          <div class="service"><a href="#">Apply for Copyright Protection</a></div>
          <div class="service"><a href="#">Order Trademark Service</a></div>
        </div>
      </div><!-- .container -->
    </div><!-- .services -->

    <div id="testimonials">
      <div class="container">
        <h2>Client Testimonials</h2>

        <div id="testimonials-carousel" class="owl-carousel">

          <div class="item">
            <blockquote>
              <p class="lead">Outstanding. Thanks for all the great customer service! Have a good weekend. Also, my friend Bryant may call you to get some help forming an LLC/ Corporation. I gave him your contact info yesterday. Thank you.</p>
              <footer>
                <cite>S. Paullin (Phoenix,AZ)</cite>
              </footer>
            </blockquote>
          </div>

          <div class="item">
            <blockquote>
              <p class="lead">Thank you very much for your trust and understanding. Everything worked out great thanks to your help.</p>
              <footer>
                <cite>B. Martin (Cleveland,GA)</cite>
              </footer>
            </blockquote>
          </div>

          <div class="item">
            <blockquote>
              <p class="lead">I love InCorp Services!</p>
              <footer>
                <cite>M. Long (Winter Garden,FL)</cite>
              </footer>
            </blockquote>
          </div>

        </div><!-- .testimonials-carousel -->


      </div><!-- .container -->
    </div><!-- .testimonials -->

    <div id="newsletter">
      <div class="container">
            <form class="form-inline">
            <div class="form-group">
              <label for="exampleInputEmail2">Stay in the know! Join our monthly newsletter.</label>
              <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Your Email">
            </div>
            <button type="submit" class="btn btn-success">Sign Up</button>
          </form>
      </div><!-- .container -->
    </div><!-- .newsletter -->

    <footer id="colophon">

      <div class="container">

        <div class="fwidget">
          <h3>Connect With Us</h3>
          <div class="fwidget-content">
            <ul class="footer-links">
              <li><a href="plus.google.com">Google Plus</a></li>
              <li><a href="facebook.com">Facebook</a></li>
              <li><a href="twitter.com">Twitter </a></li>
              <li><a href="linkedin.com">LinkedIn</a></li>
            </ul>
            <p>&copy; Copyright 1998-2016 <br>
              InCorp Services, Inc All rights reserved.</p>
          </div><!-- .fwidget-content -->
        </div><!-- .fwidget -->

        <div class="fwidget">
          <h3>Location</h3>
          <div class="fwidget-content">
            <img class="location-map" src="images/map.png" alt="map">
            <p>3773 Howard Hughes Pkwy · Suite 500S <br>
              Las Vegas, NV 89169-6014</p>
          </div><!-- .fwidget-content -->
        </div><!-- .fwidget -->

        <div class="fwidget">
          <h3>Quick Links</h3>
          <div class="fwidget-content">
            <ul class="footer-links">
              <li><a href="#">Information</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Contact Us</a></li>
              <li><a href="#">Site Map</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Terms of Service</a></li>
              <li><a href="#">Affiliate Login</a></li>
            </ul>
          </div><!-- .fwidget-content -->
        </div><!-- .fwidget -->

        <div class="fwidget">
          <ul class="footer-img-links">
            <li><a target="_blank" href="https://www.mcafeesecure.com/verify?host=incorp.com"><img src="images/McAfeeSecure.png" alt="McAfee Secured"></a></li>
            <li><a target="_blank" title="McAfee SECURE sites help keep you safe from identity theft, credit card fraud, spyware, spam, viruses and online scams" href="http://www.bbb.org/santa-barbara/business-reviews/information-bureaus/incorp-com-inc-in-westlake-village-ca-92003447/#bbbonlineclick"><img src="images/BBB_AccreditedBusiness.png" alt="Incorp.com, Inc. BBB Business Review"></a></li>
            <li><a tabindex="-1" href="https://smarticon.geotrust.com/smarticonprofile?Referer=https://www.incorp.com" onclick="return gt__md();" target="GT__SIP"><img src="images/GeoTrust.png" alt="Click for company profile wih GeoTrust"></a></li>
          </ul>
        </div><!-- .fwidget -->

      </div><!-- .container -->

      <div class="disclaimer">
        <div class="container">
          Disclaimer: Incorp.com is not a law or accounting firm and neither Incorp.com nor any of its employees provide legal or accounting services or advice and should not be relied upon as such. If legal or other accounting assistance is needed, we recommend that you seek the services of a competent professional. The content on Incorp.com should not serve as a substitute for legal advice from an attorney or accountant familiar with the facts and circumstances of your specific situation. Contact your tax adviser or legal counsel prior to making any decisions.
        </div><!-- .container -->
      </div><!-- .disclaimer -->

    </footer><!-- #colophon -->

    <!-- Incorp JavaScript
    ================================================== -->
    <script src="js/main.js"></script>

  </body>
</html>
