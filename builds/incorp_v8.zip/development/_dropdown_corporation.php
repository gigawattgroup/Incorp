<ul class="dropdown-menu dropdown-menu-large row">
  <li class="col-sm-6 col-md-3 col-color">
    <ul>
      <li class="dropdown-header">$99 Registered Agent</li>
      <li>
        <a href="#">
          Rates as Low as $67/Year With Multi-Year Service!
        </a>
      </li>
      <li>
        <a href="#">
          InCorp Offers National Registered Agent Services in All 50 States and DC. InCorp, The Premier Registered Agent Service is the best choice for comprehensive and accurate services at an attractive price!
        </a>
      </li>
    </ul>
  </li>
  <li class="col-sm-6 col-md-3 col-color">
    <ul>
      <li class="dropdown-header">Entity Formantion</li>
      <li>
        <a href="#">
          Corporation and LLC Formation Services Online!
        </a>
      </li>
      <li>
        <a href="#">
          InCorp prices starting at $99 plus applicable state fees. InCorp is the low-cost cutting edge leader in forming your new Corporation, Limited-Liability Company (LLC), or any other type of business entity in all US states and DC.
        </a>
      </li>
    </ul>
  </li>
  <li class="col-sm-6 col-md-3 col-color">
    <ul>
      <li class="dropdown-header">Foreign Qualitfication</li>
      <li>
        <a href="#">
          $149 plus state fees, plus fees for Certificate of Good Standing or certified copy of articles of incorporation/organization from the entity’s home state.
        </a>
      </li>
    </ul>
  </li>
  <li class="col-sm-6 col-md-3 col-color">
    <ul>
      <li><a class="link-header" href="#">Why incorporate?</a></li>
      <li><a class="link-header" href="#">Where to incorporate?</a></li>
      <li><a class="link-header" href="#">Compare Entity Types</a></li>
      <li class="divider"></li>
      <li><a class="link-header" href="#">Limited-Liability Partnership (LLP)</a></li>
      <li><a class="link-header" href="#">Limited Partnership (LP)</a></li>
    </ul>
  </li>
</ul><!-- .dropdown-menu -->
