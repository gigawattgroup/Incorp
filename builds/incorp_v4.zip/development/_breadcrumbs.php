<div id="breadcrumbs">
  <div class="container">
        <ol class="breadcrumb">
          <li><a href="#">Home</a></li>
          <li class="active">Select a Package</li>
        </ol><!-- .breadcrumb -->
  </div><!-- .container -->
</div><!-- #breadcrumb -->
